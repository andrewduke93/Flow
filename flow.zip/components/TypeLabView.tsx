import React, { useState, useEffect, useRef } from 'react';
import { useTitanSettings } from '../services/configService';
import { useTitanTheme } from '../services/titanTheme';
import { Type, Zap, Minus, Plus } from 'lucide-react';

/**
 * TypeLabView (Flow-Reader 2.0: Explicit Control)
 * Identity: Senior Type Designer.
 * Mission: Visible, tactile controls. Theme Aware.
 */
export const TypeLabView: React.FC = () => {
  const { settings, updateSettings } = useTitanSettings();
  const theme = useTitanTheme();
  
  const [optimisticSpeed, setOptimisticSpeed] = useState(settings.rsvpSpeed);
  const speedDebounceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
     if (Math.abs(settings.rsvpSpeed - optimisticSpeed) > 10 && !speedDebounceTimer.current) {
         setOptimisticSpeed(settings.rsvpSpeed);
     }
  }, [settings.rsvpSpeed]);

  const handleSpeedChange = (v: number) => {
    const clamped = Math.max(100, Math.min(1000, v));
    setOptimisticSpeed(clamped);
    
    if (speedDebounceTimer.current) clearTimeout(speedDebounceTimer.current);
    speedDebounceTimer.current = setTimeout(() => {
        updateSettings({ rsvpSpeed: clamped, hasCustomSpeed: true });
        speedDebounceTimer.current = null;
    }, 100);
  };

  // Simplified Font List
  const fonts = [
    { name: 'Serif', label: 'fancy', val: 'New York' },
    { name: 'Sans', label: 'clean', val: 'SF Pro' }
  ];

  return (
    <div className="flex flex-col gap-8 pt-4">
      
      {/* 1. Explicit Speed Control Row */}
      <div className="space-y-4">
        <h3 className="flex items-center gap-2 text-xs font-sans font-bold uppercase tracking-wider opacity-60 px-1 lowercase" style={{ color: theme.secondaryText }}>
           <Zap size={14} /> the pace
        </h3>
        
        <div 
            className="rounded-2xl p-4 shadow-sm border"
            style={{ 
                backgroundColor: theme.surface, 
                borderColor: theme.borderColor 
            }}
        >
            <div className="flex items-center justify-between mb-4">
                 <span className="text-sm font-semibold lowercase" style={{ color: theme.primaryText }}>speed (wpm)</span>
                 <span className="text-2xl font-serif font-bold tracking-tight tabular-nums" style={{ color: theme.primaryText }}>{optimisticSpeed}</span>
            </div>
            
            <div className="flex items-center gap-4">
                <button 
                   onClick={() => handleSpeedChange(optimisticSpeed - 25)}
                   className="w-12 h-12 rounded-full flex items-center justify-center active:scale-95 transition-all"
                   style={{ backgroundColor: theme.borderColor, color: theme.primaryText }}
                >
                    <Minus size={20} />
                </button>

                <div className="flex-1 relative h-10 flex items-center">
                    <input 
                        type="range"
                        min={100}
                        max={1000}
                        step={25}
                        value={optimisticSpeed}
                        onChange={(e) => handleSpeedChange(parseInt(e.target.value))}
                        className="w-full h-2 rounded-full appearance-none cursor-pointer focus:outline-none"
                        style={{ 
                            backgroundColor: theme.borderColor,
                            accentColor: theme.accent
                        }}
                    />
                </div>

                <button 
                   onClick={() => handleSpeedChange(optimisticSpeed + 25)}
                   className="w-12 h-12 rounded-full flex items-center justify-center active:scale-95 transition-all"
                   style={{ backgroundColor: theme.borderColor, color: theme.primaryText }}
                >
                    <Plus size={20} />
                </button>
            </div>
        </div>
      </div>

      <div className="w-full h-px" style={{ backgroundColor: theme.borderColor }} />

      {/* 2. Typography Controls */}
      <div className="space-y-4">
        <h3 className="flex items-center gap-2 text-xs font-sans font-bold uppercase tracking-wider opacity-60 px-1 lowercase" style={{ color: theme.secondaryText }}>
           <Type size={14} /> the vibe
        </h3>

        <div className="grid grid-cols-2 gap-4">
            {fonts.map(f => (
                <button
                   key={f.val}
                   onClick={() => updateSettings({ fontFamily: f.val as any })}
                   className={`flex flex-col items-center justify-center gap-2 p-6 rounded-2xl border transition-all duration-200 ${
                       settings.fontFamily === f.val ? 'shadow-md scale-[1.02]' : 'hover:scale-[1.01]'
                   }`}
                   style={{
                       backgroundColor: settings.fontFamily === f.val ? theme.primaryText : theme.surface,
                       borderColor: settings.fontFamily === f.val ? theme.primaryText : theme.borderColor,
                       color: settings.fontFamily === f.val ? theme.surface : theme.primaryText
                   }}
                >
                    <span className="text-3xl font-bold mb-1" style={{ fontFamily: getCSSFont(f.val) }}>Aa</span>
                    <div className="flex flex-col items-center">
                        <span className="text-sm font-bold">{f.name}</span>
                        <span 
                            className="text-[10px] font-bold uppercase tracking-widest"
                            style={{ 
                                color: settings.fontFamily === f.val ? theme.surface : theme.secondaryText,
                                opacity: settings.fontFamily === f.val ? 0.8 : 0.6
                            }}
                        >
                            {f.label}
                        </span>
                    </div>
                </button>
            ))}
        </div>

        <div 
            className="rounded-2xl p-4 shadow-sm border space-y-6 mt-4"
            style={{ backgroundColor: theme.surface, borderColor: theme.borderColor }}
        >
            <ControlRow label="size" value={settings.fontSize} min={14} max={40} onChange={v => updateSettings({ fontSize: v })} theme={theme} />
            <ControlRow label="room" value={settings.lineHeight} min={1.0} max={2.2} step={0.1} onChange={v => updateSettings({ lineHeight: v })} theme={theme} />
            <ControlRow label="gaps" value={settings.paragraphSpacing} min={0} max={40} onChange={v => updateSettings({ paragraphSpacing: v })} theme={theme} />
        </div>
      </div>

    </div>
  );
};

const ControlRow: React.FC<{ label: string, value: number, min: number, max: number, step?: number, onChange: (v: number) => void, theme: any }> = ({ label, value, min, max, step = 1, onChange, theme }) => (
    <div className="flex items-center gap-4">
        <span className="text-xs font-bold w-16 uppercase tracking-wide lowercase" style={{ color: theme.secondaryText }}>{label}</span>
        <input 
            type="range" 
            min={min} 
            max={max} 
            step={step} 
            value={value} 
            onChange={(e) => onChange(parseFloat(e.target.value))}
            className="flex-1 h-1.5 rounded-full appearance-none cursor-pointer"
            style={{ 
                backgroundColor: theme.borderColor,
                accentColor: theme.accent
            }}
        />
        <span className="text-xs font-bold w-8 text-right tabular-nums" style={{ color: theme.primaryText }}>{value.toFixed(step < 1 ? 1 : 0)}</span>
    </div>
);

function getCSSFont(name: string): string {
    if (name === 'New York') return 'serif';
    if (name === 'SF Pro') return 'sans-serif';
    return 'serif';
}